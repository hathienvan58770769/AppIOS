//
//  FilterCollectionViewCell.swift
//  InstagramClone
//
//  Created by The Zero2Launch Team on 3/4/17.
//  Copyright © 2017 The Zero2Launch Team. All rights reserved.
//

import UIKit

class FilterCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var filterPhoto: UIImageView!
}
