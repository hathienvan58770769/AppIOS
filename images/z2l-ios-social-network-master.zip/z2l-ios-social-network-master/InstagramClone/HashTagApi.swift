//
//  HashTagApi.swift
//  InstagramClone
//
//  Created by The Zero2Launch Team on 3/10/17.
//  Copyright © 2017 The Zero2Launch Team. All rights reserved.
//

import Foundation
import FirebaseDatabase
class HashTagApi {
    var REF_HASHTAG = FIRDatabase.database().reference().child("hashtag")
    
 
    
}
