# Build Instagram Using Swift and Firebase
This is the source code for the top-rated course ["Build Instagram to Learn Swift 4 and Firebase 4 in Depth"](http://zero2launch.io/p/swift-4-firebase-4-clone-instagram) at [zero2launch.io](http://zero2launch.io/). It's a highly-crafted, full-feature social network app which includes photo and video sharing, like, comment, follow, search, filter, hashtags,... It also serves as a template to effortlessly build high-quality, complex social network apps.

&nbsp;

![demo-short-xlight](https://cloud.githubusercontent.com/assets/24752658/23903196/0d1a8fe0-089a-11e7-9f44-3ebd389fa596.gif)

&nbsp;

